/*******************************************************************
main.c: M�tfrekvensen justeras efter frekvensen p� knapptryckningarna 
        och genomsnittstemperaturen skrivs ut i samband med
	    temperaturm�tning.
*******************************************************************/
#include "header.h"

/*******************************************************************
main: Initierar systemet vid start.
*******************************************************************/
int main(void)
{
	
	
	setup();
	while (1)
	{
		
	}

	return 0;
}
